from setuptools import setup, find_packages

setup(
    name="OkumiResponse",  # Имя пакета
    version="0.1.0",  # Версия библиотеки
    packages=find_packages(),  # Находит все пакеты в проекте (например, OkumiResponse)
    install_requires=[  # Зависимости, если они потребуются в будущем
        # Пример:
        # 'requests',  # если библиотека требует requests
        # 'numpy',  # если требуется numpy
    ],
    test_suite="OkumiResponse.tests",  # Указывает на тесты, чтобы можно было запускать тесты через setup.py
    tests_require=[  # Список зависимостей для тестов
        'pytest',  # Пример зависимости для тестирования
    ],
    author="Miss.Okumi",
    author_email="your.email@example.com",
    description="Библиотека для поиска ответов с использованием базы знаний.",
    url="https://github.com/yourusername/OkumiResponse",  # URL репозитория
    classifiers=[  # Классификаторы, которые помогут пользователям найти библиотеку
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",  # Минимальная версия Python
)
